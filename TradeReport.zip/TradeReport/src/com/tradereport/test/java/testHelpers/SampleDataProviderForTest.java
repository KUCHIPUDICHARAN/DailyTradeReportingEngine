package com.tradereport.test.java.testHelpers;

import com.tradereport.main.java.applicationlogic.tradingcalculations.SettlementDayFinder;
import com.tradereport.main.java.domain.TradeDetails;
import com.tradereport.main.java.domain.TradeInstruction;
import com.tradereport.main.java.domain.TradeType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Currency;
import java.util.HashSet;
import java.util.Set;

public class SampleDataProviderForTest {

    private static final LocalDate MONDAY    = LocalDate.of(2019, 8, 5);
    private static final LocalDate TUESDAY   = LocalDate.of(2019, 8, 6);
    private static final LocalDate WEDNESDAY = LocalDate.of(2019, 8, 7);
    private static final LocalDate THURSDAY = LocalDate.of(2019, 8, 8);
    private static final LocalDate FRIDAY = LocalDate.of(2019, 8, 9);
    private static final LocalDate SATURDAY  = LocalDate.of(2019, 8, 1);
    private static final LocalDate SUNDAY    = LocalDate.of(2019, 8, 11);

    public static Set<TradeInstruction> createSampleDataOfInstructions() {
        final Set<TradeInstruction> instructions = new HashSet<>();

        //Sample data containing same settlement date i.e 8/8/2019 for clear understanding of tests
        instructions.add(new TradeInstruction(
                "Cargill",
                TradeType.BUY,
                LocalDate.of(2019, 8, 1),
                THURSDAY,
                new TradeDetails(
                        Currency.getInstance("JPY"),
                        BigDecimal.valueOf(1),
                        100,
                        BigDecimal.valueOf(1))));

        instructions.add(new TradeInstruction(
                "Glencore",
                TradeType.BUY,
                LocalDate.of(2019, 8, 1),
                THURSDAY,
                new TradeDetails(
                        Currency.getInstance("JPY"),
                        BigDecimal.valueOf(1),
                        200,
                        BigDecimal.valueOf(1))));

        instructions.add(new TradeInstruction(
                "Koch",
                TradeType.SELL,
                LocalDate.of(2019, 8, 1),
                SATURDAY,
                new TradeDetails(
                        Currency.getInstance("JPY"),
                        BigDecimal.valueOf(0.5),
                        400,
                        BigDecimal.valueOf(1))));

        instructions.add(new TradeInstruction(
                "Gunvor",
                TradeType.SELL,
                LocalDate.of(2019, 8, 1),
                SUNDAY,
                new TradeDetails(
                        Currency.getInstance("JPY"),
                        BigDecimal.valueOf(0.5),
                        100,
                        BigDecimal.valueOf(1))));

        //Sample data containing same settlement date i.e 6/8/2019 for clear understanding of tests
        instructions.add(new TradeInstruction(
                "Trafigura",
                TradeType.BUY,
                LocalDate.of(2019, 8, 1),
                TUESDAY,
                new TradeDetails(
                        Currency.getInstance("CNY"),
                        BigDecimal.valueOf(1),
                        400,
                        BigDecimal.valueOf(1))));

        instructions.add(new TradeInstruction(
                "Mercuria",
                TradeType.SELL,
                LocalDate.of(2019, 8, 1),
                TUESDAY,
                new TradeDetails(
                        Currency.getInstance("CNY"),
                        BigDecimal.valueOf(1),
                        1000,
                        BigDecimal.valueOf(1))));

        instructions.add(new TradeInstruction(
                "Noble Group",
                TradeType.SELL,
                LocalDate.of(2019, 8, 1),
                FRIDAY,
                new TradeDetails(
                        Currency.getInstance("EUR"),
                        BigDecimal.valueOf(1.09),
                        10,
                        BigDecimal.valueOf(1))));

        //Sample data containing same settlement date i.e 7/8/2019 for clear understanding of tests
        instructions.add(new TradeInstruction(
                "Vitol",
                TradeType.BUY,
                LocalDate.of(2019, 8, 1),
                WEDNESDAY,
                new TradeDetails(
                        Currency.getInstance("AED"),
                        BigDecimal.valueOf(1),
                        500,
                        BigDecimal.valueOf(0.17))));

        instructions.add(new TradeInstruction(
                "Archer Daniels",
                TradeType.BUY,
                LocalDate.of(2019, 8, 1),
                WEDNESDAY,
                new TradeDetails(
                        Currency.getInstance("AED"),
                        BigDecimal.valueOf(1),
                        700,
                        BigDecimal.valueOf(0.17))));

        instructions.add(new TradeInstruction(
                "Bunge",
                TradeType.SELL,
                LocalDate.of(2019, 8, 1),
                MONDAY,
                new TradeDetails(
                        Currency.getInstance("GBP"),
                        BigDecimal.valueOf(1),
                        900,
                        BigDecimal.valueOf(1.17))));

        SettlementDayFinder.findSettlementDates(instructions);

        return instructions;
    }
}
