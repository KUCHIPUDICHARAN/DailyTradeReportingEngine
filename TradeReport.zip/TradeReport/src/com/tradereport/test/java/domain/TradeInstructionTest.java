package com.tradereport.test.java.domain;

import com.tradereport.main.java.domain.TradeDetails;
import com.tradereport.main.java.domain.TradeInstruction;
import com.tradereport.main.java.domain.TradeType;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Currency;

import static org.junit.Assert.assertEquals;

public class TradeInstructionTest {
    @Test
    public void calculateAmountOfTradeTest() throws Exception {
        //Setup
        final BigDecimal agreedFx = BigDecimal.valueOf(69.0);
        final BigDecimal pricePerUnit = BigDecimal.valueOf(100.25);
        final int units = 200;
        final TradeInstruction tradeInstruction = new TradeInstruction(
                "Mercuria",
                TradeType.BUY,
                LocalDate.of(2019, 3, 11),
                LocalDate.of(2019, 3, 13),
                new TradeDetails(
                        Currency.getInstance("INR"),
                        agreedFx,
                        units,
                        pricePerUnit));

        final BigDecimal expectedAmount = pricePerUnit
                .multiply(agreedFx)
                .multiply(BigDecimal.valueOf(units))
                .setScale(2, BigDecimal.ROUND_HALF_EVEN);
        //Test
        BigDecimal actualAmount = tradeInstruction.getTradeAmount();
        //Verify Results
        assertEquals(agreedFx, tradeInstruction.getAgreedFx());
        assertEquals(expectedAmount, actualAmount);
    }
}
