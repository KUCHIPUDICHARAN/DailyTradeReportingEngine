package com.tradereport.test.java.applicationlogic;

import com.tradereport.main.java.applicationlogic.tradingcalculations.SettlementDayFinder;
import com.tradereport.main.java.domain.TradeDetails;
import com.tradereport.main.java.domain.TradeInstruction;
import com.tradereport.main.java.domain.TradeType;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Currency;

import static org.junit.Assert.assertEquals;

public class SettlementDayFinderTest {

    /*
     * This test verifies that the settlement date should return the same date(9/8/2019) as the given date(Friday) is
     * a working day in AmericaEurope region
     */
    @Test
    public void testToFindSettlementDateFor_WorkingDate_InAmericaEuropeRegion() throws Exception {
        //setup
        final LocalDate expectedSettlementDate = LocalDate.of(2019, 8, 9);

        final TradeInstruction tradeInstruction = new TradeInstruction(
                "Glencore",
                TradeType.BUY,
                LocalDate.of(2019, 8, 2),
                expectedSettlementDate,
                new TradeDetails(
                        Currency.getInstance("GBP"),
                        BigDecimal.valueOf(1.17),
                        300,
                        BigDecimal.valueOf(120.5)));

        // test
        SettlementDayFinder.getSettlementDateForGivenInstruction(tradeInstruction);

        // verify
        assertEquals(expectedSettlementDate, tradeInstruction.getSettlementDate());
    }

    /*
     * This test verifies that the settlement date should return the next working date(12/8/2019) as the given date(Sunday)
     * is not a working day in AmericaEurope region
     */
    @Test
    public void testToFindSettlementDateFor_NonWorkingDate_InAmericaEuropeRegion() throws Exception {
        //setup
        final LocalDate givenSettlementDate = LocalDate.of(2019, 8, 11);

        final TradeInstruction tradeInstruction = new TradeInstruction(
                "Koch",
                TradeType.SELL,
                LocalDate.of(2019, 8, 9),
                givenSettlementDate,
                new TradeDetails(
                        Currency.getInstance("EUR"),
                        BigDecimal.valueOf(1),
                        200,
                        BigDecimal.valueOf(100.25)));

        // test
        SettlementDayFinder.getSettlementDateForGivenInstruction(tradeInstruction);

        // verify
        assertEquals(LocalDate.of(2019, 8, 12), tradeInstruction.getSettlementDate());
    }

    /*
     * This test verifies that the settlement date should return the same working date(8/8/2019) as the given date(Thursday)
     * is a working day in MiddleEast region
     */
    @Test
    public void testToFindSettlementDateFor_WorkingDate_MiddleEastRegion() throws Exception {
        //setup
        final LocalDate expectedSettlementDate = LocalDate.of(2019, 8, 8);

        final TradeInstruction tradeInstruction = new TradeInstruction(
                "Gunvor",
                TradeType.BUY,
                LocalDate.of(2019, 8, 1),
                expectedSettlementDate,
                new TradeDetails(
                        Currency.getInstance("AED"),
                        BigDecimal.valueOf(0.23),
                        600,
                        BigDecimal.valueOf(90.5)));

        // test
        SettlementDayFinder.getSettlementDateForGivenInstruction(tradeInstruction);

        // verify
        assertEquals(expectedSettlementDate, tradeInstruction.getSettlementDate());
    }

    /*
     * This test verifies that the settlement date should return the next working date(11/8/2019) as the given date(Sunday)
     * is a working day in MiddleEast region
     */
    @Test
    public void testToFindSettlementDateFor_NonWorkingDate_InMiddleEastRegion() throws Exception {
        //setup
        final LocalDate givenSettlementDate = LocalDate.of(2019, 8, 10);

        final TradeInstruction tradeInstruction = new TradeInstruction(
                "Trafigura",
                TradeType.SELL,
                LocalDate.of(2019, 8, 1),
                givenSettlementDate,
                new TradeDetails(
                        Currency.getInstance("SAR"),
                        BigDecimal.valueOf(0.50),
                        400,
                        BigDecimal.valueOf(100.25)));

        // test
        SettlementDayFinder.getSettlementDateForGivenInstruction(tradeInstruction);

        // verify
        assertEquals(LocalDate.of(2019, 8, 11), tradeInstruction.getSettlementDate());
    }
}
