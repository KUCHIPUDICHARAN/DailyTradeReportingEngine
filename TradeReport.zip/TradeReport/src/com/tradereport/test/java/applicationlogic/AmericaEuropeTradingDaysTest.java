package com.tradereport.test.java.applicationlogic;

import com.tradereport.main.java.applicationlogic.tradingregions.AmericaEuropeTradingDays;
import com.tradereport.main.java.applicationlogic.tradingregions.ITradingDays;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;

import static org.junit.Assert.assertEquals;

public class AmericaEuropeTradingDaysTest {

    private ITradingDays tradingDays;

    @Before
    public void setUp() throws Exception {
        tradingDays = AmericaEuropeTradingDays.getTradingDays();
    }

    // This test verifies the result i.e. first Monday (5/8/2019) as Saturday is not a working day in AmericaEurope Region
    @Test
    public void testToCheckFirstTradingDateAfterNonTradingDateIn_AE_Region() throws Exception {
        final LocalDate saturday = LocalDate.of(2019, 8, 3);
        assertEquals(LocalDate.of(2019, 8, 5), tradingDays.checkFirstTradingDate(saturday));
    }

    // This test verifies the result i.e. Monday only as Monday is a working day in AmericaEurope Region
    @Test
    public void testToCheckFirstTradingDateAfterTradingDateIn_AE_Region() throws Exception {
        final LocalDate monday = LocalDate.of(2019, 8, 5);
        assertEquals(monday, tradingDays.checkFirstTradingDate(monday));
    }

    // This test verifies the result i.e. first Monday (5/8/2019) as Friday is not a working day in AmericaEurope Region
    @Test
    public void testToCheckFirstTradingDateAfterFirstNonTradingDateIn_AE_Region() throws Exception {
        final LocalDate sunday = LocalDate.of(2019, 8, 4);
        assertEquals(LocalDate.of(2019, 8, 5), tradingDays.checkFirstTradingDate(sunday));
    }

}
