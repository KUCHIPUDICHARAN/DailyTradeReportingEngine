package com.tradereport.test.java.applicationlogic;

import com.tradereport.main.java.applicationlogic.tradingcalculations.DailyTradingCalculator;
import com.tradereport.main.java.domain.Rank;
import com.tradereport.test.java.testHelpers.SampleDataProviderForTest;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

public class DailyTradingCalculatorTest {

    private static final LocalDate MONDAY = LocalDate.of(2019, 8, 5);
    private static final LocalDate TUESDAY = LocalDate.of(2019, 8, 6);
    private static final LocalDate WEDNESDAY = LocalDate.of(2019, 8, 7);
    private static final LocalDate THURSDAY = LocalDate.of(2019, 8, 8);
    private static final LocalDate FRIDAY = LocalDate.of(2019, 8, 9);

    SampleDataProviderForTest sampleDataForTesting = new SampleDataProviderForTest();

    /*
     * This test verifies the daily outgoing amount for a given sample data of instructions
     */
    @Test
    public void testDailyTradeIncomingAmount() throws Exception {
        //setup and test
        final Map<LocalDate, BigDecimal> dailyIncomingAmount =
                DailyTradingCalculator.calculateIncomingAmount(sampleDataForTesting.createSampleDataOfInstructions());
        //verify
        assertEquals(5, dailyIncomingAmount.size());
        assertTrue(Objects.equals(dailyIncomingAmount.get(FRIDAY), BigDecimal.valueOf(10.90).setScale(2, BigDecimal.ROUND_HALF_EVEN)));
        assertTrue(Objects.equals(dailyIncomingAmount.get(TUESDAY), BigDecimal.valueOf(1000.00).setScale(2, BigDecimal.ROUND_HALF_EVEN)));
    }

    /*
     * This test verifies the daily incoming amount for a given sample data of instructions
     */
    @Test
    public void testDailyTradeOutgoingAmount() throws Exception {
        //setup and test
        final Map<LocalDate, BigDecimal> dailyOutgoingAmount =
                DailyTradingCalculator.calculateOutgoingAmount(sampleDataForTesting.createSampleDataOfInstructions());
        //verify
        assertEquals(3, dailyOutgoingAmount.size());
        assertTrue(Objects.equals(dailyOutgoingAmount.get(THURSDAY), BigDecimal.valueOf(300.00).setScale(2, BigDecimal.ROUND_HALF_EVEN)));
        assertTrue(Objects.equals(dailyOutgoingAmount.get(TUESDAY), BigDecimal.valueOf(400.00).setScale(2, BigDecimal.ROUND_HALF_EVEN)));
    }

    /*
     * This test verifies the daily incoming ranking for a given sample data of instructions
     */
    @Test
    public void testDailyTradeIncomingRanking() throws Exception {
        //setup and test
        final Map<LocalDate, ArrayList<Rank>> dailyIncomingRanking =
                DailyTradingCalculator.calculateDailyIncomingRanking(sampleDataForTesting.createSampleDataOfInstructions());
        //verify
        assertEquals(5, dailyIncomingRanking.size());
        assertTrue(dailyIncomingRanking.get(TUESDAY).contains(new Rank(1, TUESDAY, "Mercuria")));
        assertTrue(dailyIncomingRanking.get(MONDAY).contains(new Rank(1, MONDAY, "Bunge")));
    }

    /*
     * This test verifies the daily outgoing ranking for a given sample data of instructions
     */
    @Test
    public void testDailyTradeOutgoingRanking() throws Exception {
        //setup and test
        final Map<LocalDate, ArrayList<Rank>> dailyOutgoingRanking =
                DailyTradingCalculator.calculateDailyOutgoingRanking(sampleDataForTesting.createSampleDataOfInstructions());
        //verify
        assertEquals(3, dailyOutgoingRanking.size());

        assertEquals(2, dailyOutgoingRanking.get(THURSDAY).size());
        assertEquals(1, dailyOutgoingRanking.get(TUESDAY).size());
        assertEquals(2, dailyOutgoingRanking.get(WEDNESDAY).size());

        assertTrue(dailyOutgoingRanking.get(WEDNESDAY).contains(new Rank(1, WEDNESDAY, "Archer Daniels")));
        assertTrue(dailyOutgoingRanking.get(WEDNESDAY).contains(new Rank(2, WEDNESDAY, "Vitol")));
        assertTrue(dailyOutgoingRanking.get(TUESDAY).contains(new Rank(1, TUESDAY, "Trafigura")));
        assertTrue(dailyOutgoingRanking.get(THURSDAY).contains(new Rank(1, THURSDAY, "Glencore")));
    }
}
