package com.tradereport.test.java.applicationlogic;

import com.tradereport.main.java.applicationlogic.tradingregions.ITradingDays;
import com.tradereport.main.java.applicationlogic.tradingregions.MiddleEastTradingDays;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;

import static org.junit.Assert.assertEquals;

public class MiddleEastTradingDaysTest {

    private ITradingDays tradingDays;

    @Before
    public void setUp() throws Exception {
        tradingDays = MiddleEastTradingDays.getTradingDays();
    }

    // This test verifies the result i.e. first Sunday (4/8/2019) as Saturday is not a working day for MiddleEast Region
    @Test
    public void testToCheckFirstTradingDateAfterNonTradingDateIn_ME_Region() throws Exception {
        final LocalDate saturday = LocalDate.of(2019, 8, 3);
        assertEquals(LocalDate.of(2019, 8, 4), tradingDays.checkFirstTradingDate(saturday));
    }

    // This test verifies the result i.e. Sunday only as Sunday is a working day in MiddleEast Region
    @Test
    public void testToCheckFirstTradingDateAfterTradingDateIn_ME_Region() throws Exception {
        final LocalDate sunday = LocalDate.of(2019, 8, 4);
        assertEquals(sunday, tradingDays.checkFirstTradingDate(sunday));
    }

    // This test verifies the result i.e. first Sunday (4/8/2019) as Friday is not a working day for MiddleEast Region
    @Test
    public void testToCheckFirstTradingDateAfterFirstNonTradingDateIn_ME_Region() throws Exception {
        final LocalDate friday = LocalDate.of(2019, 8, 2);
        assertEquals(LocalDate.of(2019, 8, 4), tradingDays.checkFirstTradingDate(friday));
    }

}
