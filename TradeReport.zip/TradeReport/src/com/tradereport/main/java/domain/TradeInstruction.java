package com.tradereport.main.java.domain;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Currency;

public class TradeInstruction {

    private final String entity;
    private final TradeType tradeType;
    private final LocalDate instructionDate;
    private LocalDate settlementDate;
    private final TradeDetails tradeDetails;

    public TradeInstruction(String entity, TradeType tradeType, LocalDate instructionDate, LocalDate settlementDate, TradeDetails tradeDetails) {
        this.entity = entity;
        this.tradeType = tradeType;
        this.instructionDate = instructionDate;
        this.settlementDate = settlementDate;
        this.tradeDetails = tradeDetails;
    }

    public String getEntity() {
        return entity;
    }

    public TradeType getTradeType() {
        return tradeType;
    }

    public LocalDate getInstructionDate() {
        return instructionDate;
    }

    public LocalDate getSettlementDate() {
        return settlementDate;
    }

    public void setSettlementDate(LocalDate settlementDate) {
        this.settlementDate = settlementDate;
    }

    public TradeDetails getTradeDetails() {
        return tradeDetails;
    }

    public Currency getCurrency(){ return getTradeDetails().getCurrency(); }

    public BigDecimal getAgreedFx() {
        return getTradeDetails().getAgreedFx();
    }

    public int getUnits() {
        return getTradeDetails().getUnits();
    }

    public BigDecimal getPricePerUnit() {
        return getTradeDetails().getPricePerUnit();
    }

    public BigDecimal getTradeAmount(){ return getTradeDetails().getTradeAmount().setScale(2, BigDecimal.ROUND_HALF_EVEN);}

    @Override
    public String toString() {
        return entity;
    }
}
