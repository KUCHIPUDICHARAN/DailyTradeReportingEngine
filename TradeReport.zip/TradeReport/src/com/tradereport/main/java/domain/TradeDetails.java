package com.tradereport.main.java.domain;

import java.math.BigDecimal;
import java.util.Currency;

public class TradeDetails {

    private final Currency currency;
    private final BigDecimal agreedFx;
    private final int units;
    private final BigDecimal pricePerUnit;
    private final BigDecimal tradeAmount;

    public TradeDetails(Currency currency, BigDecimal agreedFx, int units, BigDecimal pricePerUnit) {
        this.currency = currency;
        this.agreedFx = agreedFx;
        this.units = units;
        this.pricePerUnit = pricePerUnit;
        this.tradeAmount = calculateAmountOfTrade(this);
    }

    public BigDecimal calculateAmountOfTrade(TradeDetails tradeDetails){
        return tradeDetails.getPricePerUnit()
                .multiply(BigDecimal.valueOf(tradeDetails.getUnits()))
                .multiply(tradeDetails.getAgreedFx());
    }

    public Currency getCurrency() {
        return currency;
    }

    public BigDecimal getAgreedFx() {
        return agreedFx;
    }

    public int getUnits() {
        return units;
    }

    public BigDecimal getPricePerUnit() {
        return pricePerUnit;
    }

    public BigDecimal getTradeAmount() {
        return tradeAmount;
    }
}
