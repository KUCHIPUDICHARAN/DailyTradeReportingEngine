package com.tradereport.main.java.domain;

import java.time.LocalDate;
import java.util.Objects;

public class Rank {

    private final int rank;
    private final LocalDate date;
    private final String entity;

    public Rank(int rank, LocalDate date, String entity) {
        this.rank = rank;
        this.date = date;
        this.entity = entity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rank rank1 = (Rank) o;
        return rank == rank1.rank &&
                Objects.equals(date, rank1.date) &&
                Objects.equals(entity, rank1.entity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(rank, date, entity);
    }

    @Override
    public String toString() {
        return "(" + getRank() + ") - " + getEntity();
    }

    public int getRank() {
        return rank;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getEntity() {
        return entity;
    }

}
