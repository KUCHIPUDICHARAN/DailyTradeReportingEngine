package com.tradereport.main.java.domain;

public enum TradeType {
    BUY("B"), SELL("S");

    private String tradeOption;

    TradeType(String tradeOption) {
        this.tradeOption = tradeOption;
    }

}
