package com.tradereport.main.java;

import com.tradereport.main.java.applicationlogic.reporting.IReportGenerator;
import com.tradereport.main.java.helpers.SampleDataProvider;
import com.tradereport.main.java.applicationlogic.reporting.ReportGenerator;
import com.tradereport.main.java.domain.TradeInstruction;

import java.util.Set;

public class DailyTradeReportingEngine {

    public static void main(String[] args) {
        //Create sample instructions for the project
        final Set<TradeInstruction> tradeInstructions = SampleDataProvider.createSampleInstructions();

        final IReportGenerator reportGenerator = new ReportGenerator();
        System.out.println(reportGenerator.createDailyTradeInstructionsReport(tradeInstructions));
    }
}
