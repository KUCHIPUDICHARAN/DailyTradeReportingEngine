package com.tradereport.main.java.helpers;

import com.tradereport.main.java.domain.TradeDetails;
import com.tradereport.main.java.domain.TradeInstruction;
import com.tradereport.main.java.domain.TradeType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Currency;
import java.util.HashSet;
import java.util.Set;

public class SampleDataProvider {
    public static Set<TradeInstruction> createSampleInstructions() {
        return new HashSet<>(Arrays.asList(

                new TradeInstruction(
                        "Cargill",
                        TradeType.BUY,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 22),
                        new TradeDetails(
                                Currency.getInstance("JPY"),
                                BigDecimal.valueOf(0.19),
                                150,
                                BigDecimal.valueOf(180.15))),

                new TradeInstruction(
                        "Glencore",
                        TradeType.BUY,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 19),
                        new TradeDetails(
                                Currency.getInstance("AED"),
                                BigDecimal.valueOf(0.22),
                                450,
                                BigDecimal.valueOf(150.5))),

                new TradeInstruction(
                        "Koch",
                        TradeType.SELL,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 18),
                        new TradeDetails(
                                Currency.getInstance("SAR"),
                                BigDecimal.valueOf(0.27),
                                150,
                                BigDecimal.valueOf(400.8))),

                new TradeInstruction(
                        "Gunvor",
                        TradeType.SELL,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 22),
                        new TradeDetails(
                                Currency.getInstance("EUR"),
                                BigDecimal.valueOf(0.34),
                                50,
                                BigDecimal.valueOf(500.6))),

                new TradeInstruction(
                        "Trafigura",
                        TradeType.BUY,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 18),
                        new TradeDetails(
                                Currency.getInstance("EUR"),
                                BigDecimal.valueOf(0.96),
                                140,
                                BigDecimal.valueOf(80.9))),

                new TradeInstruction(
                        "Mercuria",
                        TradeType.BUY,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 19),
                        new TradeDetails(
                                Currency.getInstance("EUR"),
                                BigDecimal.valueOf(0.96),
                                20,
                                BigDecimal.valueOf(40.6))),

                new TradeInstruction(
                        "Vitol",
                        TradeType.SELL,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 22),
                        new TradeDetails(
                                Currency.getInstance("GBP"),
                                BigDecimal.valueOf(1.09),
                                200,
                                BigDecimal.valueOf(109.5))),

                new TradeInstruction(
                        "Noble Group",
                        TradeType.SELL,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 19),
                        new TradeDetails(
                                Currency.getInstance("CNY"),
                                BigDecimal.valueOf(0.44),
                                800,
                                BigDecimal.valueOf(160.6))),

                new TradeInstruction(
                        "Bunge",
                        TradeType.BUY,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 22),
                        new TradeDetails(
                                Currency.getInstance("CNY"),
                                BigDecimal.valueOf(0.44),
                                1000,
                                BigDecimal.valueOf(320.5))),

                new TradeInstruction(
                        "Archer Daniels",
                        TradeType.SELL,
                        LocalDate.of(2019, 7, 10),
                        LocalDate.of(2019, 7, 18),
                        new TradeDetails(
                                Currency.getInstance("JPY"),
                                BigDecimal.valueOf(0.19),
                                100,
                                BigDecimal.valueOf(350.45)))
        ));
    }
}
