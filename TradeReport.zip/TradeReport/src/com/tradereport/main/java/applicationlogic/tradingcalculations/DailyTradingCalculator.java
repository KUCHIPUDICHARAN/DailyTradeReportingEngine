package com.tradereport.main.java.applicationlogic.tradingcalculations;

import com.tradereport.main.java.domain.Rank;
import com.tradereport.main.java.domain.TradeInstruction;
import com.tradereport.main.java.domain.TradeType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;

import static java.util.stream.Collectors.*;

public class DailyTradingCalculator {

    // predicate for outgoing
    private final static Predicate<TradeInstruction> buyInstructionsPredicate =
            instruction -> instruction.getTradeType().equals(TradeType.BUY);

    // predicate for incoming
    private final static Predicate<TradeInstruction> sellInstructionsPredicate =
            instruction -> instruction.getTradeType().equals(TradeType.SELL);

    //This method is to calculate the total daily outgoing trade amount in USD(For BUY)
    public static Map<LocalDate, BigDecimal> calculateOutgoingAmount(Set<TradeInstruction> instructions) {
        return calculateDailyTotalTradingAmount(instructions, buyInstructionsPredicate);
    }

    //This method is to calculate the total daily incoming trade amount in USD(For SELL)
    public static Map<LocalDate, BigDecimal> calculateIncomingAmount(Set<TradeInstruction> instructions) {
        return calculateDailyTotalTradingAmount(instructions, sellInstructionsPredicate);
    }

    //This method is to calculate the rank of daily outgoing trade amount in USD(For BUY)
    public static Map<LocalDate, ArrayList<Rank>> calculateDailyOutgoingRanking(Set<TradeInstruction> instructions) {
        return calculateRanking(instructions, buyInstructionsPredicate);
    }

    //This method is to calculate the rank of daily incoming trade amount in USD(For SELL)
    public static Map<LocalDate, ArrayList<Rank>> calculateDailyIncomingRanking(Set<TradeInstruction> instructions) {
        return calculateRanking(instructions, sellInstructionsPredicate);
    }

    //This method is to calculate the total daily trade amount in USD
    private static Map<LocalDate, BigDecimal> calculateDailyTotalTradingAmount(
            Set<TradeInstruction> instructions, Predicate<TradeInstruction> predicate) {
        Map<LocalDate, BigDecimal> amount = instructions.stream()
                .filter(predicate)
                .collect(groupingBy(tradeInstruction -> tradeInstruction.getSettlementDate(),
                        mapping(TradeInstruction::getTradeAmount,
                                reducing(BigDecimal.ZERO, BigDecimal::add))));
        return amount;
    }

    //This method is to calculate the rank of Entities on given dates
    private static Map<LocalDate, ArrayList<Rank>> calculateRanking(
            Set<TradeInstruction> instructions, Predicate<TradeInstruction> predicate) {
        final Map<LocalDate, ArrayList<Rank>> ranking = new HashMap<>();

        instructions.stream()
                .filter(predicate)
                .collect(groupingBy(TradeInstruction::getSettlementDate, toSet())).entrySet().forEach(entry -> {
            LocalDate date = entry.getKey();
            Set<TradeInstruction> dailyInstructionSet = entry.getValue();
            final AtomicInteger rank = new AtomicInteger(1);
            final ArrayList<Rank> ranks = dailyInstructionSet.stream()
                    .sorted((a, b) -> b.getTradeAmount().compareTo(a.getTradeAmount()))
                    .map(instruction -> new Rank(rank.getAndIncrement(), date, instruction.getEntity()))
                    .collect(toCollection(ArrayList::new));
            ranking.put(date, ranks);
        });

        return ranking;
    }
}
