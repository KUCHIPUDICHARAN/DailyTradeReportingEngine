package com.tradereport.main.java.applicationlogic.tradingregions;

import java.time.LocalDate;

public interface ITradingDays {
    LocalDate checkFirstTradingDate(LocalDate date);
}
