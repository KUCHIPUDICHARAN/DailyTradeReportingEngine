package com.tradereport.main.java.applicationlogic.tradingregions;

import java.time.DayOfWeek;

public class AmericaEuropeTradingDays extends TradingDays {

    private static AmericaEuropeTradingDays americaEuropeTradingDays = null;

    //Creating singleton instance if not already created
    public static AmericaEuropeTradingDays getTradingDays() {
        if (americaEuropeTradingDays == null) {
            americaEuropeTradingDays = new AmericaEuropeTradingDays();
        }
        return americaEuropeTradingDays;
    }

    private AmericaEuropeTradingDays() {
        super();
    }

    // Set trading days for the AmericaEurope trading region
    protected void setupTradingDays() {
        this.tradingDaysMap.put(DayOfWeek.SUNDAY, false);
        this.tradingDaysMap.put(DayOfWeek.MONDAY, true);
        this.tradingDaysMap.put(DayOfWeek.TUESDAY, true);
        this.tradingDaysMap.put(DayOfWeek.WEDNESDAY, true);
        this.tradingDaysMap.put(DayOfWeek.THURSDAY, true);
        this.tradingDaysMap.put(DayOfWeek.FRIDAY, true);
        this.tradingDaysMap.put(DayOfWeek.SATURDAY, false);
    }

}
