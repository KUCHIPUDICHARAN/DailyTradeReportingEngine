package com.tradereport.main.java.applicationlogic.reporting;

import com.tradereport.main.java.applicationlogic.tradingcalculations.DailyTradingCalculator;
import com.tradereport.main.java.applicationlogic.tradingcalculations.SettlementDayFinder;
import com.tradereport.main.java.domain.Rank;
import com.tradereport.main.java.domain.TradeInstruction;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

public class ReportGenerator implements IReportGenerator {
    private StringBuilder stringBuilder = new StringBuilder();

    //This method prints trade instructions report from the passed in instructions
    public String createDailyTradeInstructionsReport(Set<TradeInstruction> tradeInstructions) {
        // first check the settlement dates to comply with Trading Days
        SettlementDayFinder.findSettlementDates(tradeInstructions);

        // Build the report string will all results
        return generateDailyOutgoingBuyRanking(tradeInstructions,
                generateDailyIncomingSellRanking(tradeInstructions,
                        generateDailyIncomingSellAmount(tradeInstructions,
                                generateDailyOutgoingBuyAmount(tradeInstructions, stringBuilder))))
                .toString();
    }

    //This method create daily outgoing (BUY) amount of trade report from the passed in instructions
    private static StringBuilder generateDailyOutgoingBuyAmount(Set<TradeInstruction> instructions, StringBuilder stringBuilder) {
        //calculate trade amount for the outgoing trade instructions
        final Map<LocalDate, BigDecimal> dailyOutgoingAmount =
                DailyTradingCalculator.calculateOutgoingAmount(instructions);

        //Using string builder to append the lines to be printed for nice view of the results
        stringBuilder
                .append("\n----------------------------------------\n")
                .append("         Outgoing Daily Amount          \n")
                .append("----------------------------------------\n")
                .append("    Date         |     Trade Amount      \n")
                .append("----------------------------------------\n");

        //Using string builder to append the results based on the given dates and amount
        for (LocalDate date : dailyOutgoingAmount.keySet()) {
            stringBuilder.append(date).append("       |      ").append(dailyOutgoingAmount.get(date)).append("\n");
        }

        return stringBuilder;
    }

    //This method create daily incoming (SELL) amount of trade report from the passed in instructions
    private static StringBuilder generateDailyIncomingSellAmount(Set<TradeInstruction> instructions, StringBuilder stringBuilder) {
        //calculate trade amount for the incoming trade instructions
        final Map<LocalDate, BigDecimal> dailyOutgoingAmount =
                DailyTradingCalculator.calculateIncomingAmount(instructions);

        //Using string builder to append the lines to be printed for nice view of the results
        stringBuilder
                .append("\n----------------------------------------\n")
                .append("         Incoming Daily Amount          \n")
                .append("----------------------------------------\n")
                .append("    Date         |    Trade Amount      \n")
                .append("----------------------------------------\n");

        //Using string builder to append the results based on the given dates and amount
        for (LocalDate date : dailyOutgoingAmount.keySet()) {
            stringBuilder
                    .append(date).append("       |      ").append(dailyOutgoingAmount.get(date)).append("\n");
        }

        return stringBuilder;
    }

    //This method create daily outgoing (BUY) Rank report by date and entity from the passed in instructions
    private static StringBuilder generateDailyOutgoingBuyRanking(Set<TradeInstruction> instructions, StringBuilder stringBuilder) {
        //calculate rank for the outgoing trade instructions
        final Map<LocalDate, ArrayList<Rank>> dailyOutgoingRanking =
                DailyTradingCalculator.calculateDailyOutgoingRanking(instructions);

        //Using string builder to append the lines to be printed for nice view of the results
        stringBuilder
                .append("\n----------------------------------------\n")
                .append("         Outgoing Daily Ranking          \n")
                .append("----------------------------------------\n")
                .append("     Date    |     Rank   |   Entity     \n")
                .append("----------------------------------------\n");

        //Using string builder to append the results based on the given dates, amount and ranks
        for (LocalDate date : dailyOutgoingRanking.keySet()) {
            for (Rank rank : dailyOutgoingRanking.get(date)) {
                stringBuilder
                        .append(date).append("   |      ")
                        .append(rank.getRank()).append("     |    ")
                        .append(rank.getEntity()).append("\n");
            }
        }

        return stringBuilder;
    }

    //This method create daily incoming (SELL) Rank report by date and entity from the passed in instructions
    private static StringBuilder generateDailyIncomingSellRanking(Set<TradeInstruction> instructions, StringBuilder stringBuilder) {
        //calculate rank for the incoming trade instructions
        final Map<LocalDate, ArrayList<Rank>> dailyIncomingRanking =
                DailyTradingCalculator.calculateDailyIncomingRanking(instructions);

        //Using string builder to append the lines to be printed for nice view of the results
        stringBuilder
                .append("\n----------------------------------------\n")
                .append("         Incoming Daily Ranking          \n")
                .append("----------------------------------------\n")
                .append("     Date    |     Rank   |   Entity     \n")
                .append("----------------------------------------\n");

        //Using string builder to append the results based on the given dates, amount and ranks
        for (LocalDate date : dailyIncomingRanking.keySet()) {
            for (Rank rank : dailyIncomingRanking.get(date)) {
                stringBuilder
                        .append(date).append("   |      ")
                        .append(rank.getRank()).append("     |    ")
                        .append(rank.getEntity()).append("\n");
            }
        }

        return stringBuilder;
    }
}
