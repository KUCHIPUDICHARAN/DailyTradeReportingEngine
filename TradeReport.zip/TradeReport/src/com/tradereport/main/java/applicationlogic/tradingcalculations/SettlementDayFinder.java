package com.tradereport.main.java.applicationlogic.tradingcalculations;

import com.tradereport.main.java.applicationlogic.tradingregions.AmericaEuropeTradingDays;
import com.tradereport.main.java.applicationlogic.tradingregions.ITradingDays;
import com.tradereport.main.java.applicationlogic.tradingregions.MiddleEastTradingDays;
import com.tradereport.main.java.domain.TradeInstruction;

import java.time.LocalDate;
import java.util.Currency;
import java.util.Set;

public class SettlementDayFinder {

    public static void findSettlementDates(Set<TradeInstruction> tradeInstructions) {
        for (TradeInstruction instruction : tradeInstructions) {
            getSettlementDateForGivenInstruction(instruction);
        }
    }

    public static void getSettlementDateForGivenInstruction(TradeInstruction tradeInstruction) {
        // first of all get all working days of the region based on currency
        final ITradingDays tradingDaysForThisCurrency = getTradingDaysForThisCurrency(tradeInstruction.getCurrency());

        // calculate the settlement date
        final LocalDate updatedSettlementDate =
                tradingDaysForThisCurrency.checkFirstTradingDate(tradeInstruction.getSettlementDate());

        if (updatedSettlementDate != null) {
            tradeInstruction.setSettlementDate(updatedSettlementDate);
        }
    }

    private static ITradingDays getTradingDaysForThisCurrency(Currency currency) {

        if ((currency.getCurrencyCode().equals("AED")) ||
                (currency.getCurrencyCode().equals("SAR"))) {
            return MiddleEastTradingDays.getTradingDays();
        }
        return AmericaEuropeTradingDays.getTradingDays();
    }
}
