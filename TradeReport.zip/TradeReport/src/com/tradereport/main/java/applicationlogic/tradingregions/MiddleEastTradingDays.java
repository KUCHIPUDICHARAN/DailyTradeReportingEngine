package com.tradereport.main.java.applicationlogic.tradingregions;

import java.time.DayOfWeek;

public class MiddleEastTradingDays extends TradingDays {
    private static MiddleEastTradingDays middleEastTradingDays = null;

    //Creating singleton instance if not already created
    public static MiddleEastTradingDays getTradingDays() {
        if (middleEastTradingDays == null) {
            middleEastTradingDays = new MiddleEastTradingDays();
        }
        return middleEastTradingDays;
    }

    private MiddleEastTradingDays() {
        super();
    }

    // Set trading days for the MiddleEast trading region
    protected void setupTradingDays() {
        this.tradingDaysMap.put(DayOfWeek.SUNDAY, true);
        this.tradingDaysMap.put(DayOfWeek.MONDAY, true);
        this.tradingDaysMap.put(DayOfWeek.TUESDAY, true);
        this.tradingDaysMap.put(DayOfWeek.WEDNESDAY, true);
        this.tradingDaysMap.put(DayOfWeek.THURSDAY, true);
        this.tradingDaysMap.put(DayOfWeek.FRIDAY, false);
        this.tradingDaysMap.put(DayOfWeek.SATURDAY, false);

    }
}
