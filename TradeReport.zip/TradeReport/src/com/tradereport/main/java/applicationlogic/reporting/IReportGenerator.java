package com.tradereport.main.java.applicationlogic.reporting;

import com.tradereport.main.java.domain.TradeInstruction;

import java.util.Set;

public interface IReportGenerator {
    String createDailyTradeInstructionsReport(Set<TradeInstruction> instructions);
}
