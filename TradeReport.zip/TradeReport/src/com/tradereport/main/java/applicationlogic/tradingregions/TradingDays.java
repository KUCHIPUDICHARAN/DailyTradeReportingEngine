package com.tradereport.main.java.applicationlogic.tradingregions;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public abstract class TradingDays implements ITradingDays {

    protected Map<DayOfWeek, Boolean> tradingDaysMap = new HashMap<>();

    //Abstract method to create trading days in various regions
    protected abstract void setupTradingDays();

    public TradingDays() {
        setupTradingDays();
    }

    public LocalDate checkFirstTradingDate(LocalDate date) {
        final DayOfWeek givenDay = date.getDayOfWeek();

        // Check if the given date is a trading date and return it if yes
        if (tradingDaysMap.get(givenDay)) {
            return date;
        } else {
            // else check for the next trading date
            return checkFirstTradingDate(date.plusDays(1));
        }
    }

}
